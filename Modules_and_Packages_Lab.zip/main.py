# Task 2: Importing and Using Modules 


import math_operations    # importing all the functions in the math_operation module

user_first_num = int(input('Enter your first number: '))  # prompt user to enter any number of his/her choice
user_second_num = int(input('Enter your second number: '))  # prompt user to enter any number of his/her choice

addition_result = math_operations.add(user_first_num, user_second_num) # performing an addition operation on the two numbers and store the result in the variable addition_result
subtraction_result = math_operations.subtract(user_first_num, user_second_num) # performing a subtraction operation on the two numbers and store the result in the variable subtraction_result
multiplication_result = math_operations.multiply(user_first_num, user_second_num) # performing a multiplication operation on the two numbers and store the result in the variable multiplication_result
division_result = math_operations.divide(user_first_num, user_second_num) # performing a division operation on the two numbers and store the result in the variable division_result

print(f"Addition: {user_first_num} + {user_second_num} = {addition_result}")  # Display the result of addition operation
print(f"Subtraction: {user_first_num} - {user_second_num} = {subtraction_result}") # Display the result of subtraction operation
print(f"Multiplication: {user_first_num} x {user_second_num} = {multiplication_result}") # Display the result of multiplication operation
print(f"Division: {user_first_num} / {user_second_num} = {division_result}") # Display the result of division operation


# Task 4: Importing and Using Packages


from my_package.string_operations import reverse, count_vowels # importing reverse and count_vowels functions from the package named my_package

user_input = input('Enter a string: ')  #prompting users to enter a string
print(reverse(user_input)) # display the reversed version of the string
print(count_vowels(user_input)) # display the number of vowel letters found in the string