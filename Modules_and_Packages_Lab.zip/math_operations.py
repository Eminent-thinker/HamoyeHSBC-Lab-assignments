# Task 1: Creating and Importing Modules


def add(x,y):
    '''Takes two parameters x and y then return their sum'''
    return x + y


def subtract(x,y):
    '''Takes two parameters x and y then return their difference'''
    return x - y


def multiply(x,y):
    '''Takes two parameters x and y then multiply x by y and return their result'''
    return x * y


def divide(x,y):
    '''Takes two parameters x and y then divide x by y and return their result'''
    if y != 0:
       return x / y
    else:
        return 'Cannot divide by zero'
