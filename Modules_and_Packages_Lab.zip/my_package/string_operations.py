# Task 3: Creating and Using Packages

import string # importing the module to make all its methods accessible to use

def reverse(string):
    '''Takes a parameter: string and returns the reversed version of the input string'''
    reversed_string = string[::-1] # reading the given string in a reversed order and strore it in a variable reversed_string 
    return f'Reversed: {reversed_string}'    # return the variable


def count_vowels(string):
    '''Takes a parameter: string and return the number of vowels in the input string'''
    vowels_count = 0    # initiate the variable vowels_count in with 0
    for x in string:    # looping through all the characters in the given string
        for y in 'aeoui':  # looping through all the characters in vowel letters
           if x.lower() == y :  # compare if at any point the character in the given string equals to any character in vowel letters
             vowels_count += 1   # increase the variable vowel_count by 1 whenever the above condition is True
    return f'The number of vowel letters is: {vowels_count}' # return the variable vowel_count after the iteration through all the characters in the string


def capitalize(string):
    '''Takes a parameter: string and return the capitalized version version of the input string'''
    string_to_uppercase = string.upper()  # converting the given string to capital letters
    return string_to_uppercase   # returning the result


def is_palindrome(string):
    '''Takes a parameter: string and return True if the forward reading is equal to the reading backward and False otherwise'''
    if string == string[::-1]: # compare if the reversed string is equals to the string itself  
        return 'Palindrome: True'            # return True if the condition is True
    else:
        return 'Palindrome: False'           # return False otherwise


